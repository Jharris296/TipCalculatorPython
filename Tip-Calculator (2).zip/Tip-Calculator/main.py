#Jessica Harris - Tip Calculator- This calculator takes the users subtotal and calculates the tip and total.
print("Welcome to the Tip Calculator!")
subtotal = input("Please enter the subtotal $")
customers = input("Please enter the amount of people splitting the bill ")
tip = input("Please enter the tip percentage 10/15/20 $")
#calculation steps of total
totaltip = float(subtotal)*(float(tip)/100)
total = (float(subtotal)+float(totaltip))/float(customers)

print(f"Each person should pay ${total}")
