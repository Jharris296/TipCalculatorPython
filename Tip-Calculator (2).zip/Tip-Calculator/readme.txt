#Jessica Harris - Tip Calculator- This calculator takes the users subtotal and calculates the tip and total.
